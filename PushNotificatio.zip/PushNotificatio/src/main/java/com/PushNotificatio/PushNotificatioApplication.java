package com.PushNotificatio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PushNotificatioApplication {

	public static void main(String[] args) {
		SpringApplication.run(PushNotificatioApplication.class, args);
	}

}
